/*
 * Copyright 2018, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.example.android.marsrealestate.network

import com.example.android.marsrealestate.overview.UserInfo
import jdk.nashorn.internal.runtime.GlobalFunctions.anonymous
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.InputStream
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory


private const val BASE_URL = "https://mars.udacity.com/"


// TODO (04) Use the Moshi Builder to create a Moshi object with the KotlinJsonAdapterFactory

/**
 * Use the Retrofit builder to build a retrofit object using a Moshi converter with our Moshi
 * object pointing to the desired URL
 */
//private val retrofit = Retrofit.Builder()
//        // TODO (05) Change the ConverterFactory to the MoshiConverterFactory with our Moshi Object
//        .addConverterFactory(ScalarsConverterFactory.create())
//        .baseUrl(BASE_URL)
//        .build()

/**
 * A public interface that exposes the [getProperties] method
 */
// TODO (06) Update the MarsApiService to return a List of MarsProperty Objects
interface MarsApiService {
    @GET("realestate")
    fun getProperties(): Call<String>
}

interface RestApi {
    @Headers("Content-Type: application/json")
    @POST("api/user/login")
        fun addUser(@Body userData: UserInfo): Call<UserInfo>
}

object ServiceBuilder {


    val cf: CertificateFactory = CertificateFactory.getInstance("X.509")

    // From https://www.washington.edu/itconnect/security/ca/load-der.crt
    val cert: InputStream = BufferedInputStream(FileInputStream("load-der.crt"))
    val ca: X509Certificate = cert.use {
        cf.generateCertificate(it) as X509Certificate

        val keyStoreType = KeyStore.getDefaultType()
        val keyStore = KeyStore.getInstance(keyStoreType)
        keyStore.load(null, null)
        keyStore.setCertificateEntry("ca", ca)


        val tmfAlgorithm: String = TrustManagerFactory.getDefaultAlgorithm()
        val tmf: TrustManagerFactory = TrustManagerFactory.getInstance(tmfAlgorithm).apply {
            init(keyStore)
        }
        val sslContext: SSLContext = SSLContext.getInstance("TLS")
        sslContext.init(null, tmf.getTrustManagers(), null);

        val okHttpClient = OkHttpClient()
        okHttpClient.(sslContext.socketFactory)


        private val client = OkHttpClient.Builder().build()
        private val retrofit = Retrofit.Builder()
                .baseUrl("https://fibo.jaymart.org")
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build()

        fun <T> buildService(service: Class<T>): T {
            return retrofit.create(service)
        }
    }
}

class RestApiService {
    fun addUser(userData: UserInfo, onResult: (UserInfo?) -> Unit){
        val retrofit = ServiceBuilder.buildService(RestApi::class.java)
        retrofit.addUser(userData).enqueue(
                object : Callback<UserInfo> {
                    override fun onFailure(call: Call<UserInfo>, t: Throwable) {
                        onResult(null)
                    }
                    override fun onResponse( call: Call<UserInfo>, response: Response<UserInfo>) {
                        val addedUser = response.body()
                        onResult(addedUser)
                    }
                }
        )
    }
}

/**
 * A public Api object that exposes the lazy-initialized Retrofit service
 */
//object MarsApi {
//    val retrofitService : MarsApiService by lazy { retrofit.create(MarsApiService::class.java) }
//}
